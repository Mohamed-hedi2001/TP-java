
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class Main {
    private JFrame frmIssat;
    JLabel lblCalculPoids = new JLabel("CALCUL DU POIDS");
    JLabel lblPoids = new JLabel("0");
    private JComboBox boxMasse;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Main window = new Main();
                    window.frmIssat.setVisible(true);
                } catch (Exception var2) {
                    var2.printStackTrace();
                }

            }
        });
    }

    public Main() {
        this.initComponent();
        this.setListeners();
    }

    private void setListeners() {
        this.boxMasse.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                String str = Main.this.boxMasse.getText().trim();
                if (str.isEmpty()) {
                    Main.this.boxMasse.setText("0");
                }

                float masse = Float.parseFloat(str);
                float poids = (float)((double)masse * 9.8D);
                Main.this.lblPoids.setText(String.valueOf(poids));
            }
        });
    }

    private void initComponent() {
        this.frmIssat = new JFrame();
        this.frmIssat.setTitle("issat");
        this.frmIssat.setBounds(100, 100, 450, 300);
        this.frmIssat.setDefaultCloseOperation(3);
        this.frmIssat.getContentPane().setLayout((LayoutManager)null);
        this.lblCalculPoids.setFont(new Font("Tahoma", 1, 18));
        this.lblCalculPoids.setBounds(141, 25, 234, 32);
        this.frmIssat.getContentPane().add(this.lblCalculPoids);
        this.lblPoids.setHorizontalAlignment(0);
        this.lblPoids.setBackground(new Color(255, 200, 0));
        this.lblPoids.setBounds(192, 105, 125, 32);
        this.frmIssat.getContentPane().add(this.lblPoids);
        this.boxMasse = new JTextField();
        this.boxMasse.setHorizontalAlignment(0);
        this.boxMasse.setText("0");
        this.boxMasse.setBounds(54, 105, 108, 32);
        this.frmIssat.getContentPane().add(this.boxMasse);
        this.boxMasse.setColumns(10);
        JLabel lblMasse = new JLabel("Masse:");
        lblMasse.setFont(new Font("Tahoma", 1, 11));
        lblMasse.setBounds(54, 83, 46, 14);
        this.frmIssat.getContentPane().add(lblMasse);
        JLabel lblPoids_1 = new JLabel("Poids  (=Masse x 9.8 )");
        lblPoids_1.setFont(new Font("Tahoma", 1, 11));
        lblPoids_1.setBounds(192, 83, 156, 14);
        this.frmIssat.getContentPane().add(lblPoids_1);
        JButton btnQuitter = new JButton("Quitter");
        btnQuitter.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent arg0) {
                System.exit(0);
            }
        });
        btnQuitter.setBounds(321, 164, 89, 23);
        this.frmIssat.getContentPane().add(btnQuitter);
        JLabel lblKg = new JLabel("Kg");
        lblKg.setFont(new Font("Tahoma", 1, 11));
        lblKg.setBounds(168, 114, 28, 14);
        this.frmIssat.getContentPane().add(lblKg);
    }
}
