import java.util.Scanner;
public class main {
    Scanner x = new Scanner(System.in);
    Thread incThread = new Thread(() -> {
        for (i = 0; i <= 10; i++)
            System.out.println(x);

    });
    Thread decThread = new Thread(() -> {
        for (i = 0; i <= 10; i--)
            System.out.println(x);
    });

    public static void main(String[] args) {
        incThread.start();
        decThread.start();
    }
}